import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  timeout: 150000,
  expect: { timeout: 12000 },
  fullyParallel: false,
  workers: 1,
  use: { baseURL: 'http://127.0.0.1:4180', viewport: { width: 1440, height: 900 }, headless: true, screenshot: 'only-on-failure', trace: 'retain-on-failure' },
  webServer: { command: 'npm run dev -- --host 127.0.0.1 --port 4180', url: 'http://127.0.0.1:4180', reuseExistingServer: !process.env.CI, timeout: 30000 },
});